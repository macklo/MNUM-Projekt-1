function [A, b] = Generate(rozmiar, podpkt)
    A = Matrix1(rozmiar, podpkt);
    b = Vector1(rozmiar, podpkt);
end