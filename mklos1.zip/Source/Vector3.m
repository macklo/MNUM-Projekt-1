function [b] = Vector3()
    b = [1; -0.5; 2; 3];
end